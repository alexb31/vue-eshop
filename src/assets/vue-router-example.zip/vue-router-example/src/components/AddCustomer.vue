<template>
  <div>
    <h4>Add Customer page</h4>
    <p>[under construction...]</p>
  </div>
</template>