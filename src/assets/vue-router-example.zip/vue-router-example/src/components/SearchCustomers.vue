<template>
  <div>
    <h4>Search Customers Page</h4>
    <p>[under construction...]</p>
  </div>
</template>